<?php

$conn = mysqli_connect('localhost','root','root','my_project') or die('connection failed');

?>