<?php 
if(isset($message)){
    foreach($message as $message){
       echo '<div class="message">'.$message.'</div>';
    }
 }

 ?>